

export function AuthLayout({ children }: { children: React.ReactNode }) {
  return (
    <>
      <div className="w-full min-h-screen grid grid-cols-1 md:grid-cols-2">
        {children}
        <div className="relative w-full z-20 hidden md:flex overflow-hidden items-center justify-center">
        <div className="relative w-full h-full z-20 hidden md:flex overflow-hidden items-center justify-center">
          <div className="max-w-sm mx-auto">
            <h1 className="relative z-10 text-lg md:text-3xl  bg-clip-text text-transparent bg-gradient-to-b from-neutral-400 to-neutral-600  text-center font-sans font-bold">
              Next Wave Studio: Transforming the Businesses Process!
            </h1>
            <p></p>
            <p className="text-neutral-500 max-w-lg mx-auto my-2 text-md text-center relative z-10">
              Discover how Next Wave Studio is revolutionizing business processes with innovative solutions. Our expertise in web development, design, and digital strategy empowers businesses to thrive in the digital age. Join us on this journey of transformation and success.
            </p>
          </div>
        </div>
        </div>
      </div>
    </>
  );
}
