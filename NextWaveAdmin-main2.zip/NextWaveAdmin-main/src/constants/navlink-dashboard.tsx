import {
    IconScript
} from "@tabler/icons-react";

export const navlinksDashboard = [
    {
        href: "blog",
        label: "Blogs",
        icon: IconScript,
    }
];
