export type Navlink = {
  href: string;
  label: string;
  icon?: React.ReactNode | any;
  clickable?: boolean;
};
