export const blogLinkGenerator = ({ title }: { title: string }) => {
    return title.trim().split(/\s+/).join('-').toLowerCase();
}