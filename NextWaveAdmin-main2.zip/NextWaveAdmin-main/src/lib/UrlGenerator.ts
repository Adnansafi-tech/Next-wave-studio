const authHeader = (token: string) => ({ Authorization: `Bearer ${token}` });

const generalHeader = (clientId: string) => ({ Authorization: `Bearer ${clientId}` });

const byIdGenerator = (id: string, url: string) => ({ url: url + id })

const bySlugGenerator = (slug: string, url: string) => ({ url: url + slug })

export { authHeader, generalHeader, byIdGenerator, bySlugGenerator };