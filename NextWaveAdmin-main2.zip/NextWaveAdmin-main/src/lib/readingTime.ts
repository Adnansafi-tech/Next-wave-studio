import { htmlToText } from 'html-to-text'

export const calculateReadingTime = (htmlContent: string): number => {
  const textContent = htmlToText(htmlContent, {
    wordwrap: false,
    preserveNewlines: false,
  })

  const wordCount = textContent.split(/\s+/).filter(Boolean).length

  const wordsPerMinute = 200

  const readingTimeMinutes = Math.ceil(wordCount / wordsPerMinute)

  return readingTimeMinutes
}
