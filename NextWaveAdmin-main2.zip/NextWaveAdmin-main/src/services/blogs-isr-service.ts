import axios from "axios";
import BACKEND_API from "@/constants/api-constants";

export const getBlogBySlug = async (slug: string) => {
    const response = await axios.get(`${BACKEND_API.API_ENDPOINTS.BASE_API_URL}${BACKEND_API.API_ENDPOINTS.GETBLOGBYSLUG}/${slug}`);
    return response;
};

export const getBlogs = async () => {
    try {
        const response = await axios.get(`${BACKEND_API.API_ENDPOINTS.BASE_API_URL}${BACKEND_API.API_ENDPOINTS.GETBLOGS}`);

        if (response.status !== 200) {
            console.error(`Error: Received status code ${response.status}`);
            return [];
        }

        return response.data?.Result ?? [];
    } catch (error) {
        console.error("Error fetching blogs:", error);
        return [];
    }
};