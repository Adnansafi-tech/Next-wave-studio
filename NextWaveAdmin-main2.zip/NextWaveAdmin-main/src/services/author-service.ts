"use client";

import axios from 'axios';
import { byIdGenerator } from '@/lib/UrlGenerator';
import BACKEND_API from '@/constants/api-constants';

const getAuthorById = async (Id: string) => {
    console.log(`CategoryService | getCategories`);
    try {
        const headers = {
            'Content-Type': 'application/json'
        };

        const url = byIdGenerator(Id, `${BACKEND_API.API_ENDPOINTS.BASE_API_URL}${BACKEND_API.API_ENDPOINTS.GETAUTHORBYID}`).url;

        const blogsResponse = await axios.get(url, { headers });
        if (blogsResponse?.status === 200) {
            return {
                status: true,
                message: `Author data fetched`,
                data: blogsResponse?.data
            };
        } else {
            return {
                status: false,
                message: `Author data not found. If Error Block`,
            };
        }
    } catch (error) {
        let errorMessage = 'Oops! Something went wrong.';
        if (axios.isAxiosError(error) && error.response) {
            errorMessage = error.response.data?.message || errorMessage;
        }
        return {
            status: false,
            message: errorMessage
        };
    }
}

const handleGetAuthorById = getAuthorById

export default handleGetAuthorById;