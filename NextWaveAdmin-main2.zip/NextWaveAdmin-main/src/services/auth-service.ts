"use client";

import axios from 'axios';
import { LoginResponse, User } from './types/type';
import BACKEND_API from '@/constants/api-constants';

const login = async (user: User): Promise<LoginResponse> => {
    try {
        const requestBody = {
            EmailAddress: user.email,
            Password: user.password,
        };
        const response = await axios.post(`${BACKEND_API.API_ENDPOINTS.BASE_API_URL}/${BACKEND_API.API_ENDPOINTS.LOGIN}`, requestBody);
        if (response.data.isSuccess) {
            return {
                status: true,
                message: 'Login successful.',
                data: response.data.data
            };
        } else {
            return {
                status: false,
                message: 'Login unsuccessful.'
            };
        }
    } catch (error) {
        let errorMessage = 'Oops! Something went wrong.';
        if (axios.isAxiosError(error) && error.response) {
            errorMessage = error.response.data?.message || errorMessage;
        }
        return {
            status: false,
            message: errorMessage
        };
    }
};

const Handlelogin = { login }

export default Handlelogin;