import { UserData } from "./types/type";

const isBrowser = typeof window !== "undefined";

const setToken = (token: string) => {
    if (isBrowser) {
        localStorage.setItem('token', token);
    }
};

const getToken = (): string => {
    return isBrowser ? localStorage.getItem('token') ?? '' : '';
};

const getUserData = (): UserData | null => {
    if (isBrowser) {
        const userDataString = localStorage.getItem('userData');
        return userDataString ? JSON.parse(userDataString) : null;
    }
    return null;
};

const setUserData = (userData: UserData) => {
    if (isBrowser) {
        localStorage.setItem('userData', JSON.stringify(userData));
    }
};

const removeData = (key: string) => {
    if (isBrowser) {
        try {
            localStorage.removeItem(key);
        } catch (error) {
            console.error(`Error removing data for key ${key}:`, error);
        }
    }
};

const localStorageUtil = {
    setToken,
    getToken,
    setUserData,
    getUserData,
    removeData
};

export default localStorageUtil;