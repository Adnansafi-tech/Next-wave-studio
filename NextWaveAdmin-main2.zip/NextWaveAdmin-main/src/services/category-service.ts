"use client";

import axios from 'axios';
import BACKEND_API from '@/constants/api-constants';

const getCategories = async () => {
    console.log(`CategoryService | getCategories`);
    try {
        const requestBody = {
        };

        const blogsResponse = await axios.get(
            `${BACKEND_API.API_ENDPOINTS.BASE_API_URL}${BACKEND_API.API_ENDPOINTS.GETCATEGORIES}`,
            requestBody
        );
        if (blogsResponse?.status === 200) {
            return {
                status: true,
                message: `Categories data fetched`,
                data: blogsResponse?.data
            };
        } else {
            return {
                status: false,
                message: `Categories data not found. If Error Block`,
            };
        }
    } catch (error) {
        let errorMessage = 'Oops! Something went wrong.';
        if (axios.isAxiosError(error) && error.response) {
            errorMessage = error.response.data?.message || errorMessage;
        }
        return {
            status: false,
            message: errorMessage
        };
    }
}

const handleGetCategories = getCategories

export default handleGetCategories