import { NextApiRequest, NextApiResponse } from 'next';
import axios from 'axios';
import BACKEND_API from '@/constants/api-constants';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
    if (req.method === 'POST') {
        const { metadata, file } = req.body;

        try {
            const formData = new FormData();
            formData.append('file', file);
            formData.append('metadata', JSON.stringify(metadata));

            const headers = {
                'Content-Type': 'multipart/form-data',
                'Authorization': `Bearer ${req.headers.authorization}`,
            };

            const response = await axios.post(
                `${BACKEND_API.API_ENDPOINTS.BASE_API_URL}${BACKEND_API.API_ENDPOINTS.CREATEBLOG}`,
                formData,
                { headers }
            );

            if (response.status === 200) {
                const slug = metadata.BlogMetadata.Title.replace(/\s+/g, '-').toLowerCase();
                await res.revalidate(`/blog/${slug}`);

                res.status(200).json({ message: 'Blog created and static page regenerated successfully!' });
            } else {
                res.status(500).json({ message: 'Failed to create blog in backend' });
            }
        } catch (error) {
            console.error(error);
            res.status(500).json({ message: 'Failed to create blog' });
        }
    } else {
        res.setHeader('Allow', ['POST']);
        res.status(405).end(`Method ${req.method} Not Allowed`);
    }
}