export interface ImageDto {
    Path: string | null;
    Name: string;
    ContainerName: string;
    FolderName: string;
}

export interface FootNotesDto {
    FootNoteText?: string;
    FootNoteLink?: string;
}

export interface BlogMetadataDto {
    Title: string;
    Description: string;
    BlogAuthors: BlogAuthorDto[] | BlogAuthorDto;
    Category: CategoryDtoBlog;
    Language?: string;
    DescriptionTag?: string;
    Keywords?: string;
    ReadingTime?: string;
    Version: string;
    Status: string;
}

export interface BlogAuthorDto {
    AuthorName: string;
    AuthorPhoto: string;
    AuthorMail: string;
    AuthorLinkedIn: string;
}

export interface CategoryDtoBlog {
    Name: string;
    Description: string;
}

export interface CategoryDto {
    name: string;
    description: string;
}

export interface BlogDto {
    CreatedDateTimeUtc: string,
    Slug: string,
    Thumbnail?: ImageDto;
    MainPicture: ImageDto;
    Body: string;
    FootNotes: FootNotesDto[];
    BlogMetadata: BlogMetadataDto;
}

export interface CreateBlogDto {
    Slug: string,
    Thumbnail?: ImageDto;
    MainPicture: ImageDto;
    Body: string;
    FootNotes: FootNotesDto[];
    BlogMetadata: BlogMetadataDto;
}

export interface User {
    email: string,
    password: string
}

export interface ApiResponse {
    isSuccess: boolean;
    data: {
        IsLoggedIn: boolean;
        Token: string;
    };
}

export interface LoginSuccessResponse {
    status: boolean;
    message: string;
    data: ApiResponse['data'];
}

export interface LoginFailureResponse {
    status: boolean;
    message: string;
}

export type LoginResponse = LoginSuccessResponse | LoginFailureResponse;

export interface UserData {
    Id: string,
    FirstName: string,
    LastName: string,
    EmailAddress: string,
    Role: string,
    exp: number
}

export interface DecodedData extends UserData {
    iss: string,
    aud: string
}

export interface CategoryDto {
    Id: string,
    Name: string,
    Description: string
}

export interface CategoriesDto {
    Categories: CategoryDto[]
}

export interface AuthorDto {
    FirstName: string,
    LastName: string,
    EmailAddress: string,
    ProfilePicture: string,
    Password: string,
    LinkedIn: string,
    Twitter: string,
    Role: string,
}