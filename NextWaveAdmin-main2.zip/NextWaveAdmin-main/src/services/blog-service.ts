"use client";

import axios from 'axios';
import { CreateBlogDto } from './types/type';
import { getToken } from '@/features/Store';
import { bySlugGenerator } from '@/lib/UrlGenerator';
import BACKEND_API from '@/constants/api-constants';

const getBlogs = async () => {
    console.log(`BlogService | getBlogs`);
    try {
        const headers = {
            'Content-Type': 'application/json'
        };

        const blogsResponse = await axios.get(
            `${BACKEND_API.API_ENDPOINTS.BASE_API_URL}${BACKEND_API.API_ENDPOINTS.GETBLOGS}`,
            { headers }
        );

        if (blogsResponse?.status === 200) {
            return {
                status: true,
                message: `Blogs data fetched`,
                data: blogsResponse?.data
            };
        } else {
            return {
                status: false,
                message: `Blogs data not found. If Error Block`,
            };
        }
    } catch (error) {
        let errorMessage = 'Oops! Something went wrong.';
        if (axios.isAxiosError(error) && error.response) {
            errorMessage = error.response.data?.message || errorMessage;
        }
        return {
            status: false,
            message: errorMessage
        };
    }
}

const getBlogBySlug = async (slug: string) => {
    console.log(`BlogService | getBlogBySlug`);
    try {
        const headers = {
            'Content-Type': 'application/json'
        };

        const url = bySlugGenerator(slug, `${BACKEND_API.API_ENDPOINTS.BASE_API_URL}${BACKEND_API.API_ENDPOINTS.GETBLOGBYSLUG}`).url;

        const blogsResponse = await axios.get(
            url,
            { headers }
        );

        if (blogsResponse?.status === 200) {
            console.log('get by slug is working')
            return {
                status: true,
                message: `Blog data fetched`,
                data: blogsResponse?.data
            };
        } else {
            return {
                status: false,
                message: `Blog data not found. If Error Block`,
            };
        }
    } catch (error) {
        let errorMessage = 'Oops! Something went wrong.';
        if (axios.isAxiosError(error) && error.response) {
            errorMessage = error.response.data?.message || errorMessage;
        }
        return {
            status: false,
            message: errorMessage
        };
    }
}

const createBlog = async (blogDto: CreateBlogDto, coverPhoto: File) => {
    console.log(`BlogService | createBlog`);
    try {
        const formData = new FormData();
        formData.append('file', coverPhoto);
        formData.append('metadata', JSON.stringify(blogDto));

        const token = getToken();

        const headers = {
            'Content-Type': 'multipart/form-data',
            'Authorization': `Bearer ${token}`
        };

        const createResponse = await axios.post(
            `${BACKEND_API.API_ENDPOINTS.BASE_API_URL}${BACKEND_API.API_ENDPOINTS.CREATEBLOG}`,
            formData,
            { headers }
        );
        if (createResponse?.status === 200) {
            return {
                status: true,
                message: `Blog created successfully`,
                data: createResponse?.data
            };
        } else {
            return {
                status: false,
                message: `Blog creation failed. If Error Block`,
            };
        }
    } catch (error) {
        let errorMessage = 'Oops! Something went wrong.';
        if (axios.isAxiosError(error) && error.response) {
            errorMessage = error.response.data?.message || errorMessage;
        }
        return {
            status: false,
            message: errorMessage
        };
    }
};

const handleBlogs = { getBlogs, createBlog, getBlogBySlug }

export default handleBlogs